<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
    
?>

 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>EPR Client Portal - Report</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    
        <script>
window.onload = function() {
 
var dataPoints = [];
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	zoomEnabled: true,
	title: {
		text: "EPR Target - 2023"
	},
	axisY: {
		title: "Active",
		titleFontSize: 24,
		prefix: "Rs."
	},
	data: [{
		type: "line",
		yValueFormatString: "$#,##0.00",
		dataPoints: dataPoints
	}]
});
 
function addData(data) {
	var dps = data.price_usd;
	for (var i = 0; i < dps.length; i++) {
		dataPoints.push({
			x: new Date(dps[i][0]),
			y: dps[i][1]
		});
	}
	chart.render();
}
 
$.getJSON("https://canvasjs.com/data/gallery/php/bitcoin-price.json", addData);
 
}
</script>
    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        
<?php 
$userid=$_SESSION['id'];
$query=mysqli_query($con,"select * from users where id='$userid'");
while($result=mysqli_fetch_array($query))
{?>
                        <h4 class="mt-4">Report</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home > Report</li>
                        </ol>
                      
                        <div class="row">
                     
                            <div class="col-sm-8 note-box">
                            <h6>All Reports</h6>
                                <table class="table table-bordered">
                                <input type="date" class="form-control field" id="start" name="trip-start"       value="2018-07-22"       min="2018-01-01" max="2018-12-31">
                                <input type="date" class="form-control field" id="start" name="trip-start"       value="2018-07-22"       min="2018-01-01" max="2018-12-31">
                        
                                <select name="language" class="form-control field" id="language">
                                <option value="javascript">Category</option>
                                <option value="python">EV Battery</option>
                                <option value="c++">A<option>
                                <option value="java">B</option>
                                </select>
                                <button type="button" class="btn btn-secondary">Search</button>
                                    </tbody>
                                </table>

                                <div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script src="https://cdn.canvasjs.com/jquery.canvasjs.min.js"></script>

                            <hr>
                            <div class="note-box">
                               <table class="table  ">
                                <tr>
                                    <th>Year</th>
                                    <th>QTY</th>
                                    <th>Target Achive</th>
                                    <th>Revenue of %</th>
                                    <th>Status</th>
                                </tr>
                                <tr>
                                    <td>2023</td>
                                    <td>200KG</td>
                                    <td>1000</td>
                                    <td>50%</td>
                                    <td><p>Achive</p></td>
                                </tr>
                               </table> 
                            </div>
                            <div class="note-box"><button type="button" class="btn btn-secondary">Email</button>
                            <button type="button" class="btn btn-secondary">Share</button>
                            <button type="button" class="btn btn-secondary">Download</button>
                            <button type="button" class="btn btn-secondary">Print</button>
                            </div>
                            </div>
                            <div class="col-sm-4 side-box note-box">
                            <h6>Report Target</h6>
                            <div class="note-box">
                               
                                <h6>This Year Target</h6>
                                <p>Revenue - 500000.00</p>                                
                                <div class="revenue">% of Revenue<h1>100%</h1></div>
                            </div>
                            <div class="note-box">
                                
                                <h6>Achive Target</h6>
                                <p>Revenue - 500000.00</p>                                
                                <div class="revenue">% of Revenue<h1>100%</h1></div>
                            </div>
                            <div class="note-box">
                               
                                <h6>Target Remain</h6>
                                <p>Revenue - 500000.00</p>                                
                                <div class="revenue">% of Revenue<h1>100%</h1></div>
                            </div>
                            
                           
                           </div>
                        </div>
<?php } ?>

                    </div>
                </main>
          <?php include('includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
