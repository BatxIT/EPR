<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard | Registration and Login System</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .modal-header .close {
  margin-top: -2px;
  position: absolute!important;
  right: 20px!important;
}
.modal-dialog {
    width: 750px!important;
    max-width: 750px!important;
    margin: 30px auto;
}
.modal-content{border-radius:0px;}
.modal-header {display:block;}

.container {
    width:inherit!important;
}
.sb-sidenav .sb-sidenav-menu .nav .nav-link {  
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;   
    margin-left: 15px;
}
    </style>
    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
               
                    <div class="container-fluid px-4">
                        <h4 class="mt-4">EPR Compliance</h4>
                       
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home > Compliance</li>
                        </ol>

<?php 
$userid=$_SESSION['id'];
$query=mysqli_query($con,"select * from users where id='$userid'");
while($result=mysqli_fetch_array($query))
{?>                      


<div class="container">
<div class="row">
                     
                     <div class="col-sm-8 note-box">
                     <h6>View Order Request</h6>
                        
   <a href="#" data-toggle="modal" data-target="#myModal1"><div class="c-box"><p>RFQ</p></div></a>
   <a href="#" data-toggle="modal" data-target="#myModal2"><div class="c-box"><p>Purchase Order</p></div></a>
                     </div>
                     <div class="col-sm-4 side-box note-box">
                     <h6>Download Documents</h6>
                     <div class="note-box">
                        
                         <p>Company Profile</p>
                         <button type="button" class="btn btn-secondary">Download</button>
                     </div>
                     <div class="note-box">
                         
                         <p>GST Certificate</p>
                         <button type="button" class="btn btn-secondary">Download</button>
                     </div>
                     <div class="note-box">
                        
                         <p>Pan Card</p>
                         <button type="button" class="btn btn-secondary">Download</button>
                     </div>
                     
                    
                    </div>
                 </div>
  <div class="row">

   <div class="note-box">
   <a href="#" class="btn btn-secondary"><div class=""><p>Service Agreement</p></div></a>
   <a href="#" class="btn btn-secondary"><div class=""><p>NDA</p></div></a>
   <a href="#" class="btn btn-secondary"><div class=""><p>Form 10</p></div></a>
   <a href="#" class="btn btn-secondary"><div class=""><p>Green Certificate</p></div></a>
   <a href="#" class="btn btn-secondary"><div class=""><p>Annual Return Form 3</p></div></a>
   </div>
  </div>
</div>
                    
<h5 class="mt-4">My Activity</h5>
<div class="note-box">
<table class="recent-box">
    <tr>
        <td>Download Certificates<h4>32</h4></td>
        <td>Confirm RFQ <h4>32</h4></td>
        <td>Confirm Delivery <h4>32</h4></td>
        <td>EPR Complete <h4>32</h4></td>
        <td>Total Cell Lot <h4>32</h4></td>
     
    </tr>
</table>
      
    </div>
    
    <div class="row" >
                           
<?php } ?>

                        </div>
                       
                        <div class="container">
                        <div class="row">
                            

                        </div>
                        </div>


              
                        </div>
                   
                    </div>
              
       
            </div>
        </div>
            <!-- Modal content-->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
  
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Request For Quotation</h4>
        </div>
        <div class="modal-body">
  
          <div class="">
                          
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Sr.</th>
                <th>RFQ ID</th>
                <th>RFQ Order </th>
                <th>Weight</th>
                <th>Cell Lot</th>
                <th>Category</th>               
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>01</td>
                <td>RFQ001</td>
                <td>Order Details</td>
                <td>200KG</td>
                <td>TACO-001</td>
                <td>LFP</td>
              
                <td><button type="button" class="btn btn-secondary">View Details</button></td>
            </tr>
            
            <tr>
                <td>02</td>
                <td>RFQ002</td>
                <td>Order Details</td>
                <td>210KG</td>
                <td>TACO-001</td>
                <td>LFP</td>
               
                <td><button type="button" class="btn btn-secondary">View Details</button></td>
            </tr>
            <tr>
                <td>03</td>
                <td>RFQ003</td>
                <td>Order Details</td>
                <td>300KG</td>
                <td>TACO-001</td>
                <td>LFP</td>
              
                <td><button type="button" class="btn btn-secondary">View Details</button></td>
            </tr>
           
           
        </tbody>
        
    </table>
                                                    </div>
                                                    </div>
                                                
                            <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </div>
        
      </div>
      
    </div>
  </div>
    <!-- Modal END -->

     <!-- Modal content-->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
  
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Purchase Order</h4>
        </div>
        <div class="modal-body">
  
          <div class="">
                          
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Sr.</th>
                <th>PO ID</th>
                <th>RFQ ID</th>
                <th>Purchase Order </th>
                <th>Weight</th>
                <th>Cell Lot</th>
                <th>Category</th>               
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>01</td>
                <td>PO001</td>
                <td>RFQ001</td>
                <td>Order Details</td>
                <td>200KG</td>
                <td>TACO-001</td>
                <td>LFP</td>
              
                <td><button type="button" class="btn btn-secondary">View Details</button></td>
            </tr>
            
            <tr>
                <td>02</td>
                <td>PO002</td>
                <td>RFQ002</td>
                <td>Order Details</td>
                <td>210KG</td>
                <td>TACO-001</td>
                <td>LFP</td>
               
                <td><button type="button" class="btn btn-secondary">View Details</button></td>
            </tr>
            <tr>
                <td>03</td>
                <td>PO003</td>
                <td>RFQ003</td>
                <td>Order Details</td>
                <td>300KG</td>
                <td>TACO-001</td>
                <td>LFP</td>
              
                <td><button type="button" class="btn btn-secondary">View Details</button></td>
            </tr>
           
           
        </tbody>
        
    </table>
                                                    </div>
                                                    </div>
                                                
                            <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </div>
        
      </div>
      
    </div>
  </div>
    <!-- Modal END -->
      
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
