<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard | Registration and Login System</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
               
                    <div class="container-fluid px-4">
                        <h4 class="mt-4">Dashboard - EPR Report</h4>
                       
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Home > Dashboard</li>
                        </ol>

<?php 
$userid=$_SESSION['id'];
$query=mysqli_query($con,"select * from users where id='$userid'");
while($result=mysqli_fetch_array($query))
{?>                      

<div class="container">
  <div class="row">
    <div class="col border-box">
      EPR Target
      <p>Year - 2022-23</p>
      <div class="percent">10%</div>
      <div class="border-box1"><h5>10000.00</h5></div>

    </div>
    <div class="col border-box">
      Target Achive
      <p>Year - 2022-23</p>
      <div class="percent">10%</div>
      <div class="border-box1"><h5>10000.00</h5></div>
    </div>
    <div class="col border-box">
      Target Remain
      <p>Year - 2022-23</p>
      <div class="percent">10%</div>
      <div class="border-box1"><h5>10000.00</h5></div>
    </div>
  </div>
</div>

                        <div class="row" >
                           
<?php } ?>

                        </div>
                        <h5 class="mt-4">Battery Procurements</h5>
                        <div class="container">
                        <div class="row">
                            
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Sr.</th>
                <th>Weight</th>
                <th>RFQ No.</th>
                <th>Invoice No.</th>
                <th>Cell Lot</th>
                <th>Category</th>
                <th>Ref.</th>
                <th>Recy.</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>01</td>
                <td>150KG</td>
                <td>RFQ001</td>
                <td>IN001</td>
                <td>TACO-001<br>5000</td>
                <td>LFP</td>
                <td>Yes</td>
                <td>Yes</td>
                <td><button type="button" class="btn btn-secondary">Process</button></td>
            </tr>
            
            <tr>
                <td>02</td>
                <td>150KG</td>
                <td>RFQ001</td>
                <td>IN001</td>
                <td>TACO-001<br>5000</td>
                <td>LFP</td>
                <td>Yes</td>
                <td>Yes</td>
                <td><button type="button" class="btn btn-secondary">Process</button></td>
            </tr>
            <tr>
                <td>03</td>
                <td>150KG</td>
                <td>RFQ001</td>
                <td>IN001</td>
                <td>TACO-001<br>5000</td>
                <td>LFP</td>
                <td>Yes</td>
                <td>Yes</td>
                <td><button type="button" class="btn btn-secondary">Process</button></td>
            </tr>
            <tr>
                <td>04</td>
                <td>150KG</td>
                <td>RFQ001</td>
                <td>IN001</td>
                <td>TACO-001<br>5000</td>
                <td>LFP</td>
                <td>Yes</td>
                <td>Yes</td>
                <td><button type="button" class="btn btn-secondary">Process</button></td>
            </tr>
            <tr>
                <td>05</td>
                <td>150KG</td>
                <td>RFQ001</td>
                <td>IN001</td>                
                <td>TACO-001<br>5000</td>
                <td>LFP</td>
                <td>Yes</td>
                <td>Yes</td>
                <td><button type="button" class="btn btn-secondary">Process</button></td>
            </tr>
           
        </tbody>
        
    </table>
                        </div>
                        </div>
                        <div class="container">
  <div class="row">
    <div class="col note-box">
      <h6>Last Recent Activity Log</h6>
      <p>Recent Login at 09:40 PM</p>     
    </div>
   
  </div>
</div>

              
                        </div>
                   
                    </div>
              
       
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
