
  <div id="layoutSidenav_nav">
    
  <div class="navmain">
    <ul class="main">
       
    </ul>
  </div>
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            
                            <a class="nav-link" href="welcome.php">
                                <div class="sb-nav-link-icon"><img src="assets/002-dashboards.png" width="20"></div>
                                Dashboard
                            </a>
                            
                 
                            <a class="nav-link" href="profile.php">
                                <div class="sb-nav-link-icon"> <img src="assets/003-user.png" width="20"></div>
                                Profile
                            </a>

                            <a class="nav-link" href="epr_complience.php">
                                <div class="sb-nav-link-icon"><img src="assets/005-erp-complience.png" width="20"></div>
                                EPR Compliance
                            </a>
                            <a class="nav-link" href="battery_procurement.php">
                                <div class="sb-nav-link-icon"><img src="assets/006-user-procurement.png" width="20"></div>
                                Battery Procurement
                            </a>
                            <a class="nav-link" href="supply.php">
                                <div class="sb-nav-link-icon"><img src="assets/001-supply-chain.png" width="20"></div>
                                Supply
                            </a>
                            <a class="nav-link" href="report.php">
                                <div class="sb-nav-link-icon"><img src="assets/007-report.png" width="20"></div>
                                Report
                            </a>
  <a class="nav-link" href="change-password.php">
                                <div class="sb-nav-link-icon"><img src="assets/009-password.png" width="20"></div>
                               Change Password
                            </a>

                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><img src="assets/001-logout.png" width="20"></div>
                                Signout
                            </a>
                          
                        </div>
                    </div>
                    
                
                </nav>
            </div>
            