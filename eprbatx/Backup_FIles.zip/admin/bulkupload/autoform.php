<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">   				
   <title>Untitled Document</title>
</head>
<body>  	
        <form class="form-group" name="form1" id="form2" action="" method="post">				
	  <div class="form-group" style="margin-top:25px">
	   <center>
	      <h2>User Registration Page</h2>				
	      <table>
		<tr>
		   <td>SlNo.</td>
		   <td>: </td>
		   <td><input type="text" name="slno1" id="slno2" readonly value="<?php echo $slno4;?>">
                   </td>
		</tr>	
						
		<tr>
		   <td><label for="Nm1">User Name</label></td>
		   <td>:</td>
		   <td><input type="text" class="form-control" name="uname1" id="uname2" autofocus>
		   </td>
		</tr>						
	      </table>
	      <button type="submit" name="Submit1">Submit</button>
	      <button type="submit" name="Delete">Delete</button>
	    </center>
	  </div>	
        </form>	
     </body>
   </html>
