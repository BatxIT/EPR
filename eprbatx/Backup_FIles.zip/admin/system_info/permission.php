
<style>
	img#cimg{
		height: 15vh;
		width: 15vh;
		object-fit: cover;
		border-radius: 100% 100%;
	}
	img#cimg2{
		height: 50vh;
		width: 100%;
		object-fit: contain;
		/* border-radius: 100% 100%; */
	}
</style>
<div class="col-lg-12">
	<div class="card card-outline rounded-0 card-teal">
		<div class="card-header">
			<h5 class="card-title"> User Permission Settings</h5>
			<!-- <div class="card-tools">
				<a class="btn btn-block btn-sm btn-default btn-flat border-navy new_department" href="javascript:void(0)"><i class="fa fa-plus"></i> Add New</a>
			</div> -->
		</div>
		<div class="card-body">
			
		<input type="text" name="text" placeholder="Search User"> <button type="submit">Search</button>
		<h6>Selected User, Aditya</h6>
		<div>User, EPR Setting</div>
			<table class="table">
				<tr>
				<th>Declare</th>
				<th>Create</th>
				<th>View</th>
				<th>Edit</th>
				<th>Delete</th>
				</tr>
				<tr>
				<td>User</td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car">  </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				</tr>
				<tr>
				<td>EPR Settings</td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				</tr>
				<tr>
				<td>Request For Quotation</td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				</tr>
				<tr>
				<td>Clients</td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				</tr>
				<tr>
				<td>Battery Procurement</td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				</tr>
				<tr>
				<td>Refurbish / Recycle</td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				<td><input type="checkbox" id="vehicle2" name="vehicle2" value="Car"> </td>
				</tr>
				
			</table>
			<div class="card-footer">
			<div class="col-md-12">
				<div class="row">
					<button class="btn btn-sm btn-primary" form="system-frm">Update</button>
				</div>
			</div>
		</div>
		</div>
		
	</div>
</div>
