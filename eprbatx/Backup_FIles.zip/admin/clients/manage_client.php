<?php
require_once('./../../config.php');
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `client_list` where id = '{$_GET['id']}' and `delete_flag` = 0 ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v;
        }
    }
}
?>
<div class="container-fluid">
	<form action="" id="client-form">
		<input type="hidden" name ="id" value="<?php echo isset($id) ? $id : '' ?>">
		<div class="form-group">
			<label for="name" class="control-label">Full Name</label>
			<input type="text" name="name" id="name" class="form-control form-control-sm rounded-0" value="<?php echo isset($name) ? $name : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="name" class="control-label">Business Name</label>
			<input type="text" name="business_name" id="business_name" class="form-control form-control-sm rounded-0" value="<?php echo isset($business_name) ? $business_name : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="name" class="control-label">Email</label>
			<input type="text" name="name" id="name" class="form-control form-control-sm rounded-0" value="<?php echo isset($email) ? $email : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="name" class="control-label">Password</label>
			<input type="text" name="password" id="password" class="form-control form-control-sm rounded-0" value="<?php echo isset($password) ? $password : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="contact" class="control-label">Contact #</label>
			<input type="text" maxLength="50" name="contact" id="contact" class="form-control form-control-sm rounded-0" value="<?php echo isset($contact) ? $contact : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="name" class="control-label">Address</label>
			<input type="text" name="address" id="address" class="form-control form-control-sm rounded-0" value="<?php echo isset($address) ? $address : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="name" class="control-label">GST No.</label>
			<input type="text" name="gst" id="gst" class="form-control form-control-sm rounded-0" value="<?php echo isset($gst) ? $gst : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="name" class="control-label">Assign Person</label>
			<input type="text" name="cperson" id="cperson" class="form-control form-control-sm rounded-0" value="<?php echo isset($cperson) ? $cperson : ''; ?>"  required/>
		</div>
		<div class="form-group">
			<label for="status" class="control-label">Industries Type</label>
			<select name="status" id="status" class="form-control form-control-sm rounded-0" required="required">
				<option value="OEM" <?= isset($status) && $status == 1 ? 'selected' : '' ?>>OEM</option>
				<option value="Services" <?= isset($status) && $status == 2 ? 'selected' : '' ?>>Services</option>
				<option value="Producer" <?= isset($status) && $status == 3 ? 'selected' : '' ?>>Producer</option>
			</select>
		</div>
		<div class="form-group">
			<label for="status" class="control-label">Account Type</label>
			<select name="status" id="status" class="form-control form-control-sm rounded-0" required="required">
				<option value="Regular" <?= isset($status) && $status == 1 ? 'selected' : '' ?>>Regular</option>
				<option value="Temporary" <?= isset($status) && $status == 2 ? 'selected' : '' ?>>Temporary</option>
				
			</select>
</div>
		
		<div class="form-group">
			<label for="status" class="control-label">Status</label>
			<select name="status" id="status" class="form-control form-control-sm rounded-0" required="required">
				<option value="2" <?= isset($status) && $status == 2 ? 'selected' : '' ?>>Onboarding</option>
				<option value="1" <?= isset($status) && $status == 1 ? 'selected' : '' ?>>Active</option>
				<option value="0" <?= isset($status) && $status == 0 ? 'selected' : '' ?>>Inactive</option>
			</select>
		</div>
	</form>
</div>
<script>
	$(document).ready(function(){
		$('#client-form').submit(function(e){
			e.preventDefault();
            var _this = $(this)
			 $('.err-msg').remove();
			start_loader();
			$.ajax({
				url:_base_url_+"classes/Master.php?f=save_client",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occured",'error');
					end_loader();
				},
				success:function(resp){
					if(typeof resp =='object' && resp.status == 'success'){
						// location.reload()
						alert_toast(resp.msg, 'success')
						uni_modal("<i class='fa fa-th-list'></i> Client Details ","clients/view_client.php?id="+resp.cid)
						$('#uni_modal').on('hide.bs.modal', function(){
							location.reload()
						})
					}else if(resp.status == 'failed' && !!resp.msg){
                        var el = $('<div>')
                            el.addClass("alert alert-danger err-msg").text(resp.msg)
                            _this.prepend(el)
                            el.show('slow')
                            $("html, body").scrollTop(0);
                            end_loader()
                    }else{
						alert_toast("An error occured",'error');
						end_loader();
                        console.log(resp)
					}
				}
			})
		})

	})
</script>