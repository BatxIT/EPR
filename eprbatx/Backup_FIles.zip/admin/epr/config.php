<?php $conn = mysqli_connect("localhost", "root", "", "sts_db"); ?>
